// bt_audio.cpp — FoxR_Joni SOUND-ONLY: soundbooster over Bluetooth A2DP
// Library: pschatzmann ESP32-A2DP 1.8.x (BluetoothA2DPSource).
// Install in Arduino IDE: Library Manager -> "ESP32-A2DP" version 1.8.12.
//
// Design notes (read before changing):
// - SOUND-ONLY build: no WiFi, no BLE, no dashboard. A2DP runs when sound
//   is ON; the wifiMode parameter of btAudioLoop() is always true here.
// - Classic-only BT (ESP_BT_MODE_CLASSIC_BT) + esp_bt_controller_mem_release
//   (ESP_BT_MODE_BLE) once before the first start. BTDM mode initializes
//   the whole BLE host + controller (~50 KB heap); in the all-in-one v3
//   firmware free heap sat at ~22 KB and the Bluedroid connect path
//   asserted (host_recv_pkt_cb hci_hal_h4.c:553, hash_map_set
//   hash_map.c:129 — both NULL allocations) -> SW_CPU_RESET reboot loop.
// - Pairing is SAVED-MAC ONLY (never auto-connect to an unpaired device).
//   v3's MATCH_FIRST auto-connect grabbed a NEIGHBOR's device ("AB4088")
//   instead of the user's speaker. If no MAC is saved, A2DP stays idle
//   and tells the user to run BT:SCAN then BT:PAIR <MAC>.
// - The library's end() erases its own stored last-connection, so the paired
//   MAC is saved in OUR OWN NVS namespace ("bt", key "mac") and matched in
//   onDeviceFound during discovery. The library's set_auto_reconnect is
//   deliberately OFF (v5.1): its own reconnect raced this state machine
//   (it re-connected while we called end(false) and restarted), which
//   produced a connect/disconnect loop. One owner only reconnects: here.
// - end(false) is used, never end(true): end(true) releases BT Classic
//   controller memory permanently and disables any future start() until reboot.
// - The A2DP data callback renders the shared synth (soundSynthRender) at
//   44.1 kHz stereo (mono duplicated to L/R). No duplicated wavetable.
// - Retries are capped at 3 consecutive failures, then the state machine
//   stops (BT_GAVE_UP) until the user re-triggers. Each A2DP start/stop
//   cycle leaks heap (Bluedroid deinit never frees everything).
// - A2DP latency is ~200-300 ms (SBC): the sound lags the throttle a little.
//   That is inherent to Bluetooth audio, not a bug in this code.
#include "bt_audio.h"
#include "sound_booster.h"
#include "BluetoothA2DPSource.h"
#include <Preferences.h>
#include <atomic>
#include "esp_bt.h"  // v3.3: esp_bt_controller_mem_release (free BLE memory)

#define BT_NVS_NAMESPACE "bt"
#define BT_NVS_KEY_MAC "mac"
#define BT_A2DP_SAMPLE_RATE 44100
#define BT_CONNECT_TIMEOUT_MS 45000
#define BT_RETRY_DELAY_MS 60000
#define BT_SCAN_DURATION_MS 12000
#define BT_SLICE_FRAMES 256
// FoxR_Joni v3.2: cap consecutive failed connect attempts. Each A2DP
// start/stop cycle leaks a little heap (Bluedroid deinit never frees
// everything), so retrying forever drains the heap — observed 29,756 bytes
// free after ~80 min of cycling, which starves even the dashboard.
// After 3 consecutive failures the state machine stops and waits for the
// user to re-trigger (SOUND:OFF -> SOUND:ON, or BT:PAIR).
#define BT_MAX_CONSEC_FAILS 3
// FoxR_Joni v5.1: cap DISCONNECTS in a time window. The cap above counts
// consecutive failures, but a successful connect resets it — so a
// connect -> disconnect -> connect loop never reaches the cap and runs
// forever (observed on the user's TWS speaker, 2026-11-14). 3 disconnects
// within 3 minutes means the speaker/link is flapping: stop and wait for
// the user to re-trigger instead of cycling forever.
#define BT_MAX_DISCONNECTS 3
#define BT_DISCONNECT_WINDOW_MS 180000  // 3 minutes
#define BT_DISCONNECT_RETRY_MS 30000    // 30 s settle time after a drop

static BluetoothA2DPSource s_a2dp;
static Preferences s_prefs;

enum BtState {
  BT_IDLE,
  BT_STARTING,
  BT_CONNECTED,
  BT_WAIT_RETRY,
  BT_SCANNING,
  BT_GAVE_UP
};
static BtState s_state = BT_IDLE;
static bool s_started = false;  // start() called, end() not yet
static unsigned long s_stateSince = 0;
static unsigned long s_retryAt = 0;
static int s_consecFails = 0;
static int s_disconnects = 0;  // v5.1: drops inside the current window
static unsigned long s_disconnectWindowStart = 0;
static bool s_noMacWarned = false;  // "no speaker paired" warning printed once

// SOUND-ONLY: saved-MAC only. There is no MATCH_FIRST path: v3's
// auto-connect to the first device found grabbed a neighbor's speaker.
static esp_bd_addr_t s_savedMac = {0, 0, 0, 0, 0, 0};
static bool s_hasSavedMac = false;
static esp_bd_addr_t s_matchedMac = {0, 0, 0, 0, 0, 0};
static bool s_hasMatchedMac = false;
static int s_scanFound = 0;

// One-shot requests (set by Serial handlers in loop(), consumed by btAudioLoop)
static std::atomic<bool> s_reqScan{false};
static std::atomic<bool> s_reqRestart{false};

// ---------- MAC helpers ----------
static void macToStr(const esp_bd_addr_t mac, char *out, size_t len) {
  snprintf(out, len, "%02X:%02X:%02X:%02X:%02X:%02X",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

static int hexVal(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

// Parse "AA:BB:CC:DD:EE:FF", "AA-BB-..." or "AABBCCDDEEFF" (case-insensitive).
// Returns false on a bad format.
static bool macFromStr(const char *str, esp_bd_addr_t out) {
  if (str == nullptr) return false;
  int nibbles = 0;
  uint8_t cur = 0;
  for (const char *p = str; *p; p++) {
    if (*p == ':' || *p == '-' || *p == ' ') continue;
    int v = hexVal(*p);
    if (v < 0) return false;
    if ((nibbles % 2) == 0) {
      cur = (uint8_t)(v << 4);
    } else {
      cur |= (uint8_t)v;
      out[nibbles / 2] = cur;
    }
    nibbles++;
  }
  return nibbles == 12;
}

static bool macIsZero(const esp_bd_addr_t mac) {
  for (int i = 0; i < 6; i++) {
    if (mac[i] != 0) return false;
  }
  return true;
}

static void saveMacToNvs(const esp_bd_addr_t mac) {
  char buf[20];
  macToStr(mac, buf, sizeof(buf));
  s_prefs.begin(BT_NVS_NAMESPACE, false);
  s_prefs.putString(BT_NVS_KEY_MAC, buf);
  s_prefs.end();
  memcpy(s_savedMac, mac, 6);
  s_hasSavedMac = true;
  s_noMacWarned = false;  // a speaker is paired now; clear the warning flag
  Serial.printf("[BT] Paired MAC saved to NVS: %s\n", buf);
}

static void loadMacFromNvs() {
  s_prefs.begin(BT_NVS_NAMESPACE, true);
  String m = s_prefs.getString(BT_NVS_KEY_MAC, "");
  s_prefs.end();
  if (m.length() > 0 && macFromStr(m.c_str(), s_savedMac) &&
      !macIsZero(s_savedMac)) {
    s_hasSavedMac = true;
    Serial.printf("[BT] Saved paired MAC from NVS: %s\n", m.c_str());
  } else {
    s_hasSavedMac = false;
  }
}

// ---------- A2DP callbacks ----------
// Discovery filter: the library calls this for every compatible (audio-class)
// device found during inquiry. Return true to connect to it.
// SAVED-MAC ONLY: any device that is not the paired speaker is ignored.
// (v3's MATCH_FIRST connected to the first device found — once a
// neighbor's speaker — so it was removed.)
static bool onDeviceFound(const char *ssid, esp_bd_addr_t address, int rssi) {
  char macStr[20];
  macToStr(address, macStr, sizeof(macStr));
  Serial.printf("[BT] Found: %s [%s] RSSI %d\n", ssid ? ssid : "(no name)",
                macStr, rssi);
  if (s_state == BT_SCANNING) {
    s_scanFound++;
    return false;  // scan only: never connect
  }
  if (s_hasSavedMac && memcmp(address, s_savedMac, 6) == 0) {
    memcpy(s_matchedMac, address, 6);
    s_hasMatchedMac = true;
    Serial.println("[BT] Saved speaker found, connecting...");
    return true;
  }
  return false;  // not our speaker: ignore
}

// A2DP sound-data callback (runs in the BT task): render the shared synth
// at 44.1 kHz stereo (mono duplicated to both channels).
static int32_t onAudioData(Frame *frames, int32_t frameCount) {
  static int16_t mono[BT_SLICE_FRAMES];
  int32_t done = 0;
  while (done < frameCount) {
    int32_t n = frameCount - done;
    if (n > BT_SLICE_FRAMES) n = BT_SLICE_FRAMES;
    soundSynthRender(mono, (int)n, BT_A2DP_SAMPLE_RATE);
    for (int32_t i = 0; i < n; i++) {
      frames[done + i].channel1 = mono[i];
      frames[done + i].channel2 = mono[i];
    }
    done += n;
  }
  return frameCount;
}

// ---------- start/stop internals (called from btAudioLoop only) ----------
static void btA2dpStart(bool scanMode) {
  // FoxR_Joni v3.3: run BT Classic-only and release the BLE controller
  // memory (~30 KB) before the first start. BTDM mode left only ~22 KB
  // free heap and Bluedroid asserted during connect setup. This is
  // one-time and permanent until reboot; guarded so a later start() after
  // end(false) does not call it again.
  static bool s_bleMemReleased = false;
  if (!s_bleMemReleased) {
    esp_bt_controller_mem_release(ESP_BT_MODE_BLE);
    s_bleMemReleased = true;
    Serial.println("[BT] BLE controller memory released (Classic-only mode)");
  }
  s_a2dp.set_default_bt_mode(ESP_BT_MODE_CLASSIC_BT);
  s_a2dp.set_ssp_enabled(true);  // modern speakers use Secure Simple Pairing
  s_a2dp.set_data_callback_in_frames(onAudioData);
  s_a2dp.set_ssid_callback(onDeviceFound);
  s_a2dp.set_volume(100);
  if (scanMode) {
    s_a2dp.set_auto_reconnect(false);
    s_state = BT_SCANNING;
    s_scanFound = 0;
  } else {
    // Connect mode: caller guarantees a MAC is saved (BT_IDLE checks).
    // SAVED-MAC ONLY — never connect to an unpaired device.
    // v5.1: auto_reconnect OFF (see header note) — this state machine is
    // the only reconnect owner; the library's own reconnect fought it.
    s_a2dp.set_auto_reconnect(false);
    s_state = BT_STARTING;
  }
  s_hasMatchedMac = false;
  s_a2dp.start();  // async: discovery/connect runs in the library's task
  s_started = true;
  s_stateSince = millis();
  Serial.println(scanMode ? "[BT] Scanning for speakers (12 s)..."
                          : "[BT] A2DP starting (discovery/connect)...");
}

static void btA2dpStop() {
  if (!s_started) return;
  if (s_a2dp.is_discovery_active()) {
    s_a2dp.cancel_discovery();
  }
  // end(false): keep the BT stack usable for a later start() and for BLE.
  // Never end(true): it releases BT Classic controller memory permanently
  // and disables any future start() until reboot.
  s_a2dp.end(false);
  s_started = false;
  s_state = BT_IDLE;
  Serial.println("[BT] A2DP stopped");
}

// ---------- public API ----------
void btAudioInit() {
  loadMacFromNvs();
  Serial.println("[BT] Bluetooth audio ready (A2DP source, ESP32-A2DP 1.8.x)");
}

bool btAudioIsConnected() {
  return s_started && s_a2dp.is_connected();
}

bool btAudioIsStarted() { return s_started; }

void btAudioRequestScan() { s_reqScan.store(true, std::memory_order_release); }

bool btAudioPair(const char *macStr) {
  esp_bd_addr_t mac;
  if (macStr == nullptr || !macFromStr(macStr, mac) || macIsZero(mac)) {
    Serial.println("[BT] Format MAC salah. Contoh: BT:PAIR AA:BB:CC:DD:EE:FF");
    return false;
  }
  saveMacToNvs(mac);
  s_a2dp.clean_last_connection();  // drop the library's own last-connection
  s_reqRestart.store(true, std::memory_order_release);
  Serial.println("[BT] Pairing ke MAC baru (restart A2DP)...");
  return true;
}

void btAudioForget() {
  s_prefs.begin(BT_NVS_NAMESPACE, false);
  s_prefs.remove(BT_NVS_KEY_MAC);
  s_prefs.end();
  memset(s_savedMac, 0, 6);
  s_hasSavedMac = false;
  s_noMacWarned = false;  // re-arm the "no speaker paired" warning
  s_a2dp.clean_last_connection();
  Serial.println(
      "[BT] Saved speaker MAC dihapus. A2DP tidak akan connect sampai "
      "ada speaker baru yang di-pair (BT:SCAN lalu BT:PAIR <MAC>).");
}

void btAudioSavedMac(char *out, size_t len) {
  if (out == nullptr || len == 0) return;
  if (s_hasSavedMac) {
    macToStr(s_savedMac, out, len);
  } else {
    out[0] = '\0';
  }
}

void btAudioPrintStatus() {
  char macStr[20];
  btAudioSavedMac(macStr, sizeof(macStr));
  Serial.printf("[BT] Status: %s | %s | saved MAC: %s\n",
                s_started ? "started" : "stopped",
                btAudioIsConnected() ? "CONNECTED" : "not connected",
                macStr[0] ? macStr : "(none)");
}

void btAudioLoop(bool soundOn, bool wifiMode) {
  // Scan request (only when A2DP is idle)
  if (s_reqScan.exchange(false, std::memory_order_acq_rel)) {
    if (s_started) {
      if (s_a2dp.is_connected()) {
        char macStr[20];
        macToStr(s_hasMatchedMac ? s_matchedMac : s_savedMac, macStr,
                 sizeof(macStr));
        // v5.1: get_name() can be NULL (cheap speakers / name never
        // fetched) — %s with NULL crashes in strlen (LoadProhibited).
        const char *devName = s_a2dp.get_name();
        Serial.printf(
            "[BT] Already connected to %s [%s]. SOUND:OFF dulu untuk scan.\n",
            devName ? devName : "(unknown)", macStr);
      } else {
        Serial.println(
            "[BT] A2DP sedang discovery/connect. SOUND:OFF dulu untuk scan.");
      }
    } else if (!wifiMode) {
      Serial.println("[BT] Scan hanya di mode WiFi.");
    } else {
      btA2dpStart(true);  // scan mode
    }
  }

  // Restart request (after BT:PAIR)
  if (s_reqRestart.exchange(false, std::memory_order_acq_rel)) {
    if (s_started) btA2dpStop();
    s_consecFails = 0;  // fresh attempt budget for the new speaker
    s_disconnects = 0;  // v5.1: fresh disconnect window too
    if (s_state == BT_GAVE_UP) s_state = BT_IDLE;
    // next iteration starts again (if soundOn && wifiMode)
  }

  // Enforce desired state: A2DP runs only with sound ON in WiFi mode.
  // Exception: a running scan (BT:SCAN, sound OFF) is allowed to finish;
  // a transport switch to BLE still stops everything, scan included.
  if (!wifiMode) {
    if (s_started) btA2dpStop();
    s_state = BT_IDLE;
    return;
  }
  if (!soundOn && s_state != BT_SCANNING) {
    if (s_started) btA2dpStop();
    s_state = BT_IDLE;
    s_consecFails = 0;  // SOUND:OFF resets the attempt budget
    s_disconnects = 0;  // v5.1: and the disconnect window
    return;
  }

  switch (s_state) {
    case BT_IDLE:
      // SAVED-MAC ONLY: never start discovery without a paired speaker.
      // (v3's MATCH_FIRST auto-connect grabbed a neighbor's device.)
      if (!s_hasSavedMac) {
        if (!s_noMacWarned) {
          Serial.println(
              "[BT] No speaker paired — A2DP idle. Use BT:SCAN then "
              "BT:PAIR <MAC> to pair your speaker.");
          s_noMacWarned = true;
        }
        break;
      }
      btA2dpStart(false);
      break;

    case BT_STARTING: {
      if (s_a2dp.is_connected()) {
        s_state = BT_CONNECTED;
        s_stateSince = millis();
        s_consecFails = 0;  // success resets the attempt budget
        // No auto-save here: by construction the connected device IS the
        // saved MAC (onDeviceFound only accepts it).
        char macStr[20];
        macToStr(s_hasMatchedMac ? s_matchedMac : s_savedMac, macStr,
                 sizeof(macStr));
        // v5.1: get_name() can be NULL — %s with NULL crashes in strlen
        // (LoadProhibited panic at connect, observed 2026-11-14 on the
        // user's TWS speaker: backtrace strlen <- vsnprintf <- printf
        // <- btAudioLoop). Guard it.
        const char *devName = s_a2dp.get_name();
        Serial.printf(
            "[BT] Connected to %s [%s] — sound via Bluetooth speaker "
            "(free heap: %u bytes)\n",
            devName ? devName : "(unknown)", macStr,
            (unsigned int)ESP.getFreeHeap());
      } else if (millis() - s_stateSince > BT_CONNECT_TIMEOUT_MS) {
        s_consecFails++;
        Serial.printf(
            "[BT] Connect timeout (45 s) — gagal %d/%d, free heap: %u. "
            "Pastikan speaker nyala + pairing mode.\n",
            s_consecFails, BT_MAX_CONSEC_FAILS,
            (unsigned int)ESP.getFreeHeap());
        btA2dpStop();
        if (s_consecFails >= BT_MAX_CONSEC_FAILS) {
          s_state = BT_GAVE_UP;
          Serial.println(
              "[BT] Berhenti mencoba (3x gagal) supaya heap tidak habis. "
              "Nyalakan speaker + pairing mode, lalu SOUND:OFF dan SOUND:ON "
              "untuk coba lagi, atau BT:PAIR <MAC>.");
        } else {
          s_state = BT_WAIT_RETRY;
          s_retryAt = millis() + BT_RETRY_DELAY_MS;
        }
      }
      break;
    }

    case BT_CONNECTED: {
      if (!s_a2dp.is_connected()) {
        // v5.1: windowed disconnect cap. A connect resets s_consecFails,
        // so counting disconnects there never stops a flap loop.
        unsigned long now = millis();
        if (s_disconnects == 0 ||
            now - s_disconnectWindowStart > BT_DISCONNECT_WINDOW_MS) {
          s_disconnects = 1;
          s_disconnectWindowStart = now;
        } else {
          s_disconnects++;
        }
        Serial.printf(
            "[BT] Speaker disconnected — putus %d/%d dalam 3 menit, "
            "free heap: %u.\n",
            s_disconnects, BT_MAX_DISCONNECTS,
            (unsigned int)ESP.getFreeHeap());
        btA2dpStop();
        if (s_disconnects >= BT_MAX_DISCONNECTS) {
          s_state = BT_GAVE_UP;
          Serial.println(
              "[BT] Speaker putus 3x dalam 3 menit — berhenti mencoba "
              "supaya tidak connect/disconnect terus. Cek speaker "
              "(nyala? baterai? kejauhan?), lalu SOUND:OFF dan SOUND:ON "
              "untuk coba lagi, atau BT:PAIR <MAC>.");
        } else {
          s_state = BT_WAIT_RETRY;
          s_retryAt = now + BT_DISCONNECT_RETRY_MS;
        }
      }
      break;
    }

    case BT_WAIT_RETRY: {
      if (millis() >= s_retryAt) {
        s_state = BT_IDLE;  // next iteration starts again
      }
      break;
    }

    case BT_SCANNING: {
      if (millis() - s_stateSince > BT_SCAN_DURATION_MS) {
        Serial.printf(
            "[BT] Scan selesai: %d speaker ditemukan. Pakai BT:PAIR <MAC> "
            "untuk pairing.\n",
            s_scanFound);
        btA2dpStop();
        s_state = BT_IDLE;
      }
      break;
    }

    case BT_GAVE_UP:
      // Waiting for the user to re-trigger (SOUND:OFF -> SOUND:ON or
      // BT:PAIR). No automatic retries: each start/stop cycle leaks heap.
      break;
  }
}
