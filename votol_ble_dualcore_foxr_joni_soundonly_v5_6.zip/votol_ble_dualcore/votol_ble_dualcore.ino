/*
 * =============================================
 * FoxR_Joni SOUND-ONLY — dedicated soundbooster
 * =============================================
 * CAN (Votol EM100, 250 kbps, listen-only) -> RPM + amps
 *   -> wavetable engine synth -> Bluetooth A2DP speaker
 *   (paired MAC only) or wired I2S MAX98357A fallback.
 *
 * NO WiFi, NO BLE, NO dashboard, NO OTA. This is deliberate:
 * the all-in-one v3 firmware left only ~22 KB free heap and
 * Bluedroid asserted (host_recv_pkt_cb / hash_map_set) into a
 * reboot loop. Stripping WiFi + web + BLE host leaves 150 KB+
 * free heap, so the A2DP connect path can allocate safely.
 *
 * Updates via USB / esptool only (no OTA in this build).
 * Monitoring needs the separate v4-monitor firmware; switching
 * firmwares means reflashing.
 *
 * Serial commands (115200):
 *   SOUND:ON / SOUND:OFF   enable/disable sound (saved to NVS,
 *                           default ON for this build)
 *   BT:SCAN                list nearby BT audio devices (12 s)
 *   BT:PAIR <MAC>          pair a speaker, save MAC to NVS
 *   BT:FORGET              forget the paired speaker
 *   BT:STATUS              BT status line
 *   STATUS                 RPM / amps / sound / voice / BT / free heap
 *   VOICE                  show current voice + the voice menu
 *   VOICE:1 .. VOICE:5     select a voice (saved to NVS)
 *   VOICE:NEXT             cycle to the next voice
 * (v5.1: NO physical voice button. The first attempt used the DevKitC
 * BOOT button (GPIO0), but GPIO0 is wired to the auto-reset circuit
 * (CP2102 DTR/RTS) — Serial Monitor traffic pulls it LOW repeatedly,
 * so voices cycled by themselves. Do NOT re-add a BOOT-button control;
 * a real button needs its own GPIO + wiring.)
 *
 * Voices: 1 "Halus" (smooth, v3 original), 2 "Galak" (aggressive),
 * 3 "Nge-bass" (deep), 4 "Sport" (bright). See sound_booster.h.
 * CAN parsing (handleCANMessage + SOC table) is verbatim from the
 * v3 firmware — same frame IDs, same RPM/amps math.
 */
#include <Arduino.h>
#include "driver/twai.h"
#include <atomic>
#include <Preferences.h>
#include "sound_booster.h"  // Wavetable synth + wired I2S (MAX98357A)
#include "bt_audio.h"       // Bluetooth A2DP source (paired MAC only)

// === CONFIGURATION ===
#define CAN_TX_PIN GPIO_NUM_21
#define CAN_RX_PIN GPIO_NUM_22
#define LED_PIN 2
// NOTE (v5.1): no BOOT-button voice control — see the header comment.
// GPIO0 + the DevKitC auto-reset circuit = phantom presses.

#define CAN_TASK_STACK_SIZE 4096
#define CAN_TASK_PRIORITY 3  // Higher priority for real-time CAN
#define SOUND_TASK_STACK_SIZE 4096
#define SOUND_TASK_PRIORITY 1

static const uint32_t MUTEX_TIMEOUT_MS = 5;  // Mutex wait timeout

// === Vehicle Mode Enum (used by the CAN parser) ===
enum VehicleMode : uint8_t {
  MODE_PARK = 0,
  MODE_STAND,
  MODE_CHARGING,
  MODE_DRIVE,
  MODE_SPORT,
  MODE_REVERSE,
  MODE_BRAKE
};

// === RTOS Objects ===
SemaphoreHandle_t dataMutex = NULL;
SemaphoreHandle_t nvsMutex = NULL;
TaskHandle_t canTaskHandle = NULL;
TaskHandle_t soundTaskHandle = NULL;

Preferences preferences;

// NVS-safe write helpers (wrap NVS writes in mutex)
static inline void nvsWriteBool(const char* key, bool val) {
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    preferences.putBool(key, val);
    xSemaphoreGive(nvsMutex);
  }
}
static inline void nvsWriteInt(const char* key, int val) {
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    preferences.putInt(key, val);
    xSemaphoreGive(nvsMutex);
  }
}

// === SOC lookup table ===
const uint16_t socToBms[101] = {
  0, 60,70,80,90,95,105,115,125,135,140,150,160,170,180,185,195,205,215,225,
  230,240,250,260,270,275,285,295,305,315,320,330,340,350,360,365,375,385,395,405,
  410,420,430,440,450,455,465,475,485,495,500,510,520,530,540,550,555,565,575,585,
  590,600,610,620,630,635,645,655,665,675,680,690,700,710,720,725,735,745,755,765,
  770,780,790,800,810,815,825,835,845,855,860,870,880,890,900,905,915,925,935,945,950
};

float getSoCFromLookup(uint16_t raw) {
  if (raw >= socToBms[100]) return 100.0f;
  if (raw <= socToBms[0]) return 0.0f;

  for (int i = 0; i < 100; i++) {
    if (raw >= socToBms[i] && raw <= socToBms[i + 1]) {
      float range = (float)(socToBms[i + 1] - socToBms[i]);
      float delta = (float)(raw - socToBms[i]);
      if (range == 0) return (float)i;
      return (float)i + (delta / range);
    }
  }
  return 0.0f;
}

// === Data state ===
// CRITICAL real-time data: atomics (lock-free, no mutex needed)
std::atomic<int32_t> atomicAmpereRaw{0};  // Store as int (x10) for atomic
std::atomic<int32_t> atomicVoltsRaw{0};   // Store as int (x10) for atomic
std::atomic<int32_t> atomicPowerRaw{0};   // Store as int for atomic
std::atomic<int> atomicRPM{0};
std::atomic<int> atomicSpeed{0};
std::atomic<VehicleMode> atomicMode{MODE_PARK};  // Thread-safe mode
std::atomic<bool> canDataReady{false};  // True after first valid SOC frame

// Non-critical data: protected by dataMutex. Only RPM/amps are consumed
// by the sound task; the rest is kept so handleCANMessage stays verbatim.
int valRPM = 0;
int valSpeed = 0;
float valVolts = 0.0f;
float valAmpere = 0.0f;
float valPower = 0.0f;

int valSOC = 0;
int valCtrlTemp = 0;
int valMotorTemp = 0;
int valBattTemp = 0;

uint16_t valCells[23] = {0};
uint8_t valCellTemps[5] = {0};

float valRemainingCapacity = 0.0f;
float valFullCapacity = 0.0f;

int valSOH = 0;
uint16_t valCycleCount = 0;

uint16_t valHighestCellVolt = 0;
uint8_t valHighestCellNum = 0;
uint16_t valLowestCellVolt = 0;
uint8_t valLowestCellNum = 0;
uint16_t valAvgCellVolt = 0;

uint8_t valMaxTemp = 0;
uint8_t valMaxTempCell = 0;
uint8_t valMinTemp = 0;
uint8_t valMinTempCell = 0;

uint8_t valBalanceMode = 0;
uint8_t valBalanceStatus = 0;
uint8_t valBalanceBits[4] = {0};

uint16_t rawCurrentHex = 0;
uint16_t rawVoltageHex = 0;
uint16_t rawSOCHex = 0;
char rawBalanceHexBuffer[24] = "00 00 00 00 00 00";

// Charger data (mutex-protected)
float valChargerVoltage = 0.0f;
float valChargerCurrent = 0.0f;
uint8_t valChargerStatus = 0;
bool chargerConnected = false;
unsigned long lastChargerMsg = 0;

// BMS Info (mutex-protected)
bool bmsChargingFlag = false;     // 0x0AB40D09 byte[0]=1 when charging
bool oriChargerDetected = false;  // 0x10261041 only from ORI charger
unsigned long lastOriChargerMsg = 0;
char bmsHwVersion[8] = "";  // 0x0A750D09 "H:v21"
char bmsFwVersion[8] = "";  // 0x0A760D09 "F:v23"

// TWAI mode: always LISTEN_ONLY in this build (never transmits).
// Kept as a variable because the parser's ORI-charger branch reads it.
bool currentTwaiModeNormal = false;

std::atomic<uint32_t> canMessagesPerSec{0};  // Written by CAN task (Core 0)
uint32_t canMsgCount = 0;                    // Only used in CAN task (Core 0)
uint32_t lastSecond = 0;                     // Only used in CAN task (Core 0)

unsigned long lastLEDBlink = 0;
bool ledState = false;

// =============================================
// CAN PARSING (runs on Core 0) — verbatim from v3
// =============================================
void handleCANMessage(twai_message_t &msg) {
  uint32_t id = msg.identifier;

  // REMOVED: Aggressive prefix filter to prevent missing unknown IDs
  // uint8_t prefix = id >> 24;
  // if (prefix != 0x0A && prefix != 0x0E && prefix != 0x18 && prefix != 0x10) return;



  // Controller basic
  if (id == 0x0A010810 && msg.data_length_code >= 8) {
    // OPTIMIZATION: Update Atomic variables IMMEDIATELY (No Mutex needed)
    int rpm = msg.data[2] | (msg.data[3] << 8);
    int speed = (int)(rpm * 0.1033f);
    atomicRPM.store(rpm, std::memory_order_release);
    atomicSpeed.store(speed, std::memory_order_release);

    // Parse mode and update atomic (no mutex needed for atomic)
    uint8_t m = msg.data[1];
    VehicleMode newMode = MODE_PARK;  // Default for unknown modes

    if (m == 0x00) newMode = MODE_PARK;
    else if (m == 0x61) newMode = MODE_CHARGING;
    else if (m == 0x70) newMode = MODE_DRIVE;
    else if (m == 0x50 || m == 0xF0 || m == 0x30 || m == 0xF8) newMode = MODE_REVERSE;
    else if (m == 0x72 || m == 0xB2) newMode = MODE_BRAKE;
    else if (m == 0xB0) newMode = MODE_SPORT;
    else if (m == 0x78 || m == 0x08) newMode = MODE_STAND;
    // Unknown modes default to MODE_PARK (already set above)

    atomicMode.store(newMode, std::memory_order_release);

    // Update non-critical data with Mutex
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      valRPM = rpm;
      valSpeed = speed;
      valCtrlTemp = msg.data[4];
      valMotorTemp = msg.data[5];
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // Battery temp sensors
  if (id == 0x0E6C0D09 && msg.data_length_code >= 5) {
     if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      int sum = 0;
      for (int i = 0; i < 5; i++) {
        valCellTemps[i] = msg.data[i];
        sum += (int)valCellTemps[i];
      }
      valBattTemp = sum / 5;
      xSemaphoreGive(dataMutex);
     }
    return;
  }

  // General info 1 (Voltage/Current/Capacity) - CRITICAL FOR REAL-TIME AMPERE
  if (id == 0x0A6D0D09 && msg.data_length_code >= 8) {
    // OPTIMIZATION: Decode and update Atomic variables IMMEDIATELY (No Mutex needed)
    uint16_t vRaw = (uint16_t)((msg.data[0] << 8) | msg.data[1]);
    float volts = vRaw * 0.1f;
    atomicVoltsRaw.store((int32_t)(volts * 10.0f), std::memory_order_release);

    uint16_t iRawU = (uint16_t)((msg.data[2] << 8) | msg.data[3]);
    int16_t iRawS = (int16_t)iRawU;
    float ampere = iRawS * 0.1f;
    atomicAmpereRaw.store((int32_t)(ampere * 10.0f), std::memory_order_release);

    float power = volts * ampere;
    atomicPowerRaw.store((int32_t)power, std::memory_order_release);

    // Update non-critical shared data with Mutex
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      if (fabs(ampere) < 0.2f) ampere = 0.0f; // Zero clamping for display
      valVolts = volts;
      valAmpere = ampere;
      valPower = power;
      rawVoltageHex = vRaw;
      rawCurrentHex = iRawU;

      uint16_t remainCap = (uint16_t)((msg.data[4] << 8) | msg.data[5]);
      valRemainingCapacity = remainCap * 0.1f;

      uint16_t fullCap = (uint16_t)((msg.data[6] << 8) | msg.data[7]);
      valFullCapacity = fullCap * 0.1f;
      
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // Battery health
  if (id == 0x0A6E0D09 && msg.data_length_code >= 6) {
    // Mark data ready BEFORE mutex (atomic, lock-free)
    // This ensures flag is set even if mutex temporarily unavailable
    canDataReady.store(true, std::memory_order_release);
    
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      uint16_t socVal = (uint16_t)((msg.data[0] << 8) | msg.data[1]);
      rawSOCHex = socVal;

      valSOC = (int)getSoCFromLookup(socVal);
      if (valSOC > 100) valSOC = 100;
      if (valSOC < 0) valSOC = 0;

      uint16_t sohVal = (uint16_t)((msg.data[2] << 8) | msg.data[3]);
      valSOH = (int)(sohVal * 0.1f);
      if (valSOH > 100) valSOH = 100;

      valCycleCount = (uint16_t)((msg.data[4] << 8) | msg.data[5]);
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // Cell voltage stats
  if (id == 0x0A6F0D09 && msg.data_length_code >= 8) {
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      valHighestCellVolt = (uint16_t)((msg.data[0] << 8) | msg.data[1]);
      valHighestCellNum  = msg.data[2];
      valLowestCellVolt  = (uint16_t)((msg.data[3] << 8) | msg.data[4]);
      valLowestCellNum   = msg.data[5];
      valAvgCellVolt     = (uint16_t)((msg.data[6] << 8) | msg.data[7]);
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // Temp stats
  if (id == 0x0A700D09 && msg.data_length_code >= 6) {
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      valMaxTemp = msg.data[0];
      valMaxTempCell = msg.data[1];
      valMinTemp = msg.data[4];
      valMinTempCell = msg.data[5];
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // Balance status
  if (id == 0x0A730D09 && msg.data_length_code >= 6) {
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      valBalanceMode = msg.data[0];
      valBalanceStatus = msg.data[1];
      valBalanceBits[0] = msg.data[2];
      valBalanceBits[1] = msg.data[3];
      valBalanceBits[2] = msg.data[4];
      valBalanceBits[3] = msg.data[5];

      snprintf(rawBalanceHexBuffer, sizeof(rawBalanceHexBuffer), "%02X %02X %02X %02X %02X %02X",
              msg.data[0], msg.data[1], msg.data[2], msg.data[3], msg.data[4], msg.data[5]);
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // Cell volt blocks 0x0E64..0x0E69
  if ((id & 0xFFF0FFFF) == 0x0E600D09) {
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      int baseIndex = -1;
      switch (id) {
        case 0x0E640D09: baseIndex = 0;  break;
        case 0x0E650D09: baseIndex = 4;  break;
        case 0x0E660D09: baseIndex = 8;  break;
        case 0x0E670D09: baseIndex = 12; break;
        case 0x0E680D09: baseIndex = 16; break;
        case 0x0E690D09: baseIndex = 20; break;
        default: break;
      }
      if (baseIndex >= 0) {
        for (int i = 0; i < 4 && (baseIndex + i) < 23; i++) {
          int off = i * 2;
          if (off + 1 < msg.data_length_code) {
            valCells[baseIndex + i] = (uint16_t)((msg.data[off] << 8) | msg.data[off + 1]);
          }
        }
      }
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // External Charger Messages (Protokol Charger)
  // Was labeled CCS/China Charger Standard, but could be generic.
  if ((id == 0x1810D0F3 || id == 0x1811D0F3) && msg.data_length_code >= 5) {
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      uint16_t vRaw = (uint16_t)((msg.data[0] << 8) | msg.data[1]);
      valChargerVoltage = vRaw * 0.1f;

      uint16_t iRaw = (uint16_t)((msg.data[2] << 8) | msg.data[3]);
      valChargerCurrent = iRaw * 0.1f;

      valChargerStatus = msg.data[4];
      chargerConnected = true;
      lastChargerMsg = millis();
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // BMS Charging Flag (0x0AB40D09) - byte[0]=1 when charging
  if (id == 0x0AB40D09 && msg.data_length_code >= 1) {
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      bmsChargingFlag = (msg.data[0] == 0x01);
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // BMS Hardware Version (0x0A750D09) - ASCII "H:v21"
  if (id == 0x0A750D09 && msg.data_length_code >= 6) {
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      size_t copyLen = min((size_t)msg.data_length_code, sizeof(bmsHwVersion) - 1);
      memcpy(bmsHwVersion, msg.data, copyLen);
      bmsHwVersion[copyLen] = '\0';
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // BMS Firmware Version (0x0A760D09) - ASCII "F:v23"
  if (id == 0x0A760D09 && msg.data_length_code >= 6) {
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
      size_t copyLen = min((size_t)msg.data_length_code, sizeof(bmsFwVersion) - 1);
      memcpy(bmsFwVersion, msg.data, copyLen);
      bmsFwVersion[copyLen] = '\0';
      xSemaphoreGive(dataMutex);
    }
    return;
  }

  // ORI Charger Detection (0x10261041) - only present with original charger
  // CRITICAL FIX: In NORMAL mode, ESP32 receives its own transmitted messages!
  // If we're in NORMAL mode, WE are the sender → ignore to prevent self-detection
  // which would set oriChargerDetected=true → oriTimeout=false → kill our own injector.
  // Only detect ORI charger in LISTEN_ONLY mode (we can't TX, so it must be real ORI).
  if (id == 0x10261041) {
    if (!currentTwaiModeNormal) {
      // We're in LISTEN_ONLY → this IS from ORI charger
      if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
        oriChargerDetected = true;
        lastOriChargerMsg = millis();
        xSemaphoreGive(dataMutex);
      }
    }
    // else: In NORMAL mode → this is our own echo, ignore
    return;
  }



}

// =============================================
// CAN TASK (Core 0 - High Priority)
// Trimmed from v3: drain RX queue -> parse -> LED blink -> CAN rate.
// (SOC saves, charger timeouts and the injector lived here in v3;
// this build has no dashboard, no NVS SOC backup and never transmits.)
// =============================================
void canTask(void *pvParameters) {
  (void)pvParameters;
  twai_message_t message;
  bool gotMessage = false;

  while (true) {
    gotMessage = false;

    // Drain CAN RX queue - process as many as possible to avoid overflow
    while (twai_receive(&message, 0) == ESP_OK) {
      handleCANMessage(message);
      canMsgCount++;
      gotMessage = true;
    }

    // LED feedback
    if (gotMessage) {
      digitalWrite(LED_PIN, HIGH);
      lastLEDBlink = millis();
      ledState = true;
    } else if (ledState && (millis() - lastLEDBlink > 50)) {
      digitalWrite(LED_PIN, LOW);
      ledState = false;
    }

    // CAN rate per second
    uint32_t nowSec = millis() / 1000;
    if (nowSec != lastSecond) {
      canMessagesPerSec.store(canMsgCount, std::memory_order_release);
      canMsgCount = 0;
      lastSecond = nowSec;
    }

    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// =============================================
// SOUND BOOSTER TASK (Core 1, lowest priority)
// Verbatim logic from v3: keeps the shared synth state fresh from CAN
// data (~every 20 ms) for both outputs, runs the BT state machine,
// and renders one 16 ms I2S chunk as fallback when no BT speaker is
// connected. Sleeps 100 ms when sound is off (near-zero idle CPU).
// Sound-only build: no transport modes, so btAudioLoop always gets
// wifiMode=true (A2DP is governed by sound ON/OFF alone).
// =============================================
void soundTask(void *pvParameters) {
  (void)pvParameters;
  for (;;) {
    if (soundBoosterIsEnabled()) {
      int rpm = atomicRPM.load(std::memory_order_acquire);
      float amps = atomicAmpereRaw.load(std::memory_order_acquire) / 10.0f;
      // v5.3: CAN flowing = bike ON = idle hum even at RPM 0.
      bool canActive =
          canMessagesPerSec.load(std::memory_order_acquire) > 0;
      soundSynthSetCanActive(canActive);
      // Keep synth state fresh for BOTH outputs (A2DP renders from it in
      // the BT task; stale state would keep playing the last tone).
      soundSynthSetState(rpm, amps);
      btAudioLoop(true, true);
      // I2S fallback only when no BT speaker is connected (idle hum
      // included: CAN active counts, not just RPM/amps).
      if (!btAudioIsConnected() && (rpm > 0 || amps > 0.5f || canActive)) {
        soundBoosterUpdate(rpm, amps);
        vTaskDelay(pdMS_TO_TICKS(10));
        continue;
      }
      vTaskDelay(pdMS_TO_TICKS(20));
    } else {
      // Sound off: still run the BT loop so a scan (BT:SCAN) can run and
      // any running A2DP session is stopped.
      btAudioLoop(false, true);
      vTaskDelay(pdMS_TO_TICKS(100));
    }
  }
}

// =============================================
// VOICE MENU — Serial commands only (v5.1: BOOT button removed, see note)
// =============================================
static void printVoiceMenu() {
  int cur = soundVoiceGet();
  Serial.println("--- Sound voices ---");
  for (int i = 1; i <= SOUND_VOICE_COUNT; i++) {
    Serial.printf("  %d. %-8s %s\n", i, soundVoiceName(i),
                  (i == cur) ? "<-- current" : "");
  }
  Serial.println("Use VOICE:1..5 to select, VOICE:NEXT to cycle.");
}

// Select a voice (1-based, clamped), announce it, persist to NVS.
static void setVoice(int voice) {
  soundVoiceSet(voice);
  int v = soundVoiceGet();
  nvsWriteInt("voice", v);
  Serial.printf("[Voice] %d. %s\n", v, soundVoiceName(v));
}

// =============================================
// STATUS — one-shot report for the STATUS command
// =============================================
static void printStatus() {
  int rpm = atomicRPM.load(std::memory_order_acquire);
  float amps = atomicAmpereRaw.load(std::memory_order_acquire) / 10.0f;
  char macStr[20];
  btAudioSavedMac(macStr, sizeof(macStr));
  Serial.println("--- FoxR_Joni SOUND-ONLY status ---");
  Serial.printf("RPM: %d | Amps: %.1f A | CAN: %u msg/s\n", rpm, amps,
                (unsigned int)canMessagesPerSec.load(std::memory_order_acquire));
  Serial.printf("Sound: %s | Output: %s\n",
                soundBoosterIsEnabled() ? "ON" : "OFF",
                btAudioIsConnected() ? "Bluetooth A2DP" : "I2S (wired)");
  Serial.printf("Voice: %d. %s\n", soundVoiceGet(),
                soundVoiceName(soundVoiceGet()));
  Serial.printf("Drive: %s\n", soundSynthDriveStateName());
  Serial.printf("BT: %s | Paired MAC: %s\n",
                btAudioIsConnected() ? "CONNECTED" : "not connected",
                macStr[0] ? macStr : "(none)");
  Serial.printf("Free heap: %u bytes\n", (unsigned int)ESP.getFreeHeap());
}

// =============================================
// SETUP
// =============================================
void setup() {
  Serial.begin(115200);
  delay(100);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // Create mutexes
  dataMutex = xSemaphoreCreateMutex();
  nvsMutex = xSemaphoreCreateMutex();
  if (dataMutex == NULL || nvsMutex == NULL) {
    while (1);  // Critical error - halt
  }

  preferences.begin("votol", false);

  // Voice preset: restore from NVS, default 1 "Halus" (v3 sound).
  int voiceSaved = preferences.getInt("voice", 1);
  soundVoiceSet(voiceSaved);

  // Sound booster: ON by default in this build (it IS a soundbooster).
  // A saved OFF from an earlier firmware is still respected.
  bool soundSaved = preferences.getBool("sound", true);
  soundBoosterSetEnabled(soundSaved);
  soundBoosterSaveDone();
  if (soundSaved) {
    soundBoosterBegin();
  }

  // Bluetooth audio: load the saved paired speaker MAC from NVS.
  // A2DP itself starts from soundTask when sound is ON (saved MAC only).
  btAudioInit();

  // CAN (TWAI) Setup - LISTEN_ONLY (never transmits, no ACK clashes
  // with the speedometer). Same config as v3.
  twai_general_config_t g_config =
      TWAI_GENERAL_CONFIG_DEFAULT(CAN_TX_PIN, CAN_RX_PIN, TWAI_MODE_LISTEN_ONLY);
  g_config.rx_queue_len = 50;  // Larger queue to prevent data loss

  twai_timing_config_t t_config = TWAI_TIMING_CONFIG_250KBITS();
  twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();

  if (twai_driver_install(&g_config, &t_config, &f_config) == ESP_OK) {
    twai_start();
    Serial.println("[CAN] TWAI started (LISTEN_ONLY, 250 kbps)");
  } else {
    Serial.println("[CAN] ERROR: TWAI driver install failed!");
  }

  // Create tasks on specific cores (no commTask in this build)
  xTaskCreatePinnedToCore(
    canTask,              // Task function
    "CAN_Task",           // Name
    CAN_TASK_STACK_SIZE,  // Stack size
    NULL,                 // Parameters
    CAN_TASK_PRIORITY,    // Priority (higher = more important)
    &canTaskHandle,       // Task handle
    0                     // Core 0
  );

  xTaskCreatePinnedToCore(
    soundTask,            // Soundbooster (I2S + A2DP)
    "Sound_Task",
    SOUND_TASK_STACK_SIZE,
    NULL,
    SOUND_TASK_PRIORITY,
    &soundTaskHandle,
    1                     // Core 1
  );

  // Startup banner
  char macStr[20];
  btAudioSavedMac(macStr, sizeof(macStr));
  Serial.println("\n========================================");
  Serial.println("  FoxR_Joni SOUND-ONLY (v1.0)");
  Serial.println("  CAN -> engine sound -> BT A2DP / I2S");
  Serial.println("  NO WiFi / NO BLE / NO dashboard / NO OTA");
  Serial.printf("  Free heap at boot: %u bytes\n",
                (unsigned int)ESP.getFreeHeap());
  Serial.printf("  Paired speaker: %s\n",
                macStr[0] ? macStr : "(none - BT:SCAN then BT:PAIR <MAC>)");
  Serial.printf("  Sound: %s | Voice: %d. %s\n",
                soundBoosterIsEnabled() ? "ON" : "OFF",
                soundVoiceGet(), soundVoiceName(soundVoiceGet()));
  Serial.println("  Commands: SOUND:ON/OFF, BT:SCAN, BT:PAIR <MAC>,");
  Serial.println("            BT:FORGET, BT:STATUS, STATUS, VOICE");
  Serial.println("========================================\n");
}

// =============================================
// LOOP — Serial command handler + NVS save
// =============================================
void loop() {
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();

    if (input.equalsIgnoreCase("SOUND:ON")) {
      Serial.println("[Serial] Sound booster: ON");
      soundBoosterSetEnabled(true);
      soundBoosterBegin();
      // State saved by save-pending check below
    }
    else if (input.equalsIgnoreCase("SOUND:OFF")) {
      Serial.println("[Serial] Sound booster: OFF");
      soundBoosterSetEnabled(false);
      soundBoosterEnd();
      // State saved by save-pending check below; A2DP stops via soundTask
    }
    else if (input.equalsIgnoreCase("BT:SCAN")) {
      Serial.println("[Serial] BT scan requested (12 s)...");
      btAudioRequestScan();
    }
    else if (input.equalsIgnoreCase("BT:FORGET")) {
      btAudioForget();
    }
    else if (input.equalsIgnoreCase("BT:STATUS")) {
      btAudioPrintStatus();
    }
    else if (input.startsWith("BT:PAIR") || input.startsWith("bt:pair")) {
      // "BT:PAIR AA:BB:CC:DD:EE:FF" (colon after PAIR also accepted)
      String mac = input.substring(7);
      mac.trim();
      btAudioPair(mac.c_str());
    }
    else if (input.equalsIgnoreCase("STATUS")) {
      printStatus();
    }
    else if (input.equalsIgnoreCase("VOICE")) {
      printVoiceMenu();
    }
    else if (input.equalsIgnoreCase("VOICE:NEXT")) {
      setVoice(soundVoiceGet() % SOUND_VOICE_COUNT + 1);
    }
    else if (input.startsWith("VOICE:") || input.startsWith("voice:")) {
      // "VOICE:1" .. "VOICE:5"
      int v = input.substring(6).toInt();
      if (v >= 1 && v <= SOUND_VOICE_COUNT) {
        setVoice(v);
      } else {
        Serial.println("[Voice] Unknown voice. Use VOICE:1..4 or VOICE:NEXT.");
        printVoiceMenu();
      }
    }
    else if (input.length() > 0) {
      Serial.println("[Serial] Unknown command: " + input);
    }
  }

  // Save sound-booster state changes (flag raised by SOUND:ON/OFF)
  if (soundBoosterSavePending()) {
    nvsWriteBool("sound", soundBoosterIsEnabled());
    soundBoosterSaveDone();
    Serial.printf("[Main] Sound setting saved: %s\n",
                  soundBoosterIsEnabled() ? "ON" : "OFF");
  }

  vTaskDelay(pdMS_TO_TICKS(100));
}
