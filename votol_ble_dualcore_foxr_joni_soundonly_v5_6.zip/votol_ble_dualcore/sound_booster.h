// sound_booster.h — FoxR_Joni SOUND-ONLY soundbooster
// Sound follows CAN data: RPM -> pitch, amps -> volume.
//
// Two outputs share ONE synth core (no duplicated wavetable or pitch math):
//   - Wired: ESP32 -> MAX98357A I2S amp -> 4 ohm speaker
//            (BCLK GPIO26, LRCLK GPIO25, DIN GPIO33, VCC 5V, GND GND)
//   - Bluetooth: ESP32 A2DP source -> BT speaker (see bt_audio.h)
// Output selection lives in bt_audio.cpp: BT speaker connected -> A2DP,
// otherwise I2S fallback. SOUND:ON/OFF only toggles ON/OFF.
//
// Voices: 5 switchable sound presets (see soundVoiceSet). Both outputs
// follow the selected voice. Voice index is persisted in NVS ("voice").
// Voice 5 "Real Engine" (v5.5) plays a recorded engine loop (engine_loop.h)
// resampled to follow RPM instead of a wavetable.
#ifndef SOUND_BOOSTER_H
#define SOUND_BOOSTER_H

#include <Arduino.h>

#define SOUND_VOICE_COUNT 5

// ---- Voice presets (1-based) ----
// 1 "Halus" (smooth, v3 original), 2 "Galak" (aggressive), 3 "Nge-bass"
// (deep), 4 "Sport" (bright), 5 "Real Engine" (recorded loop, v5.5).
// Out-of-range values are clamped.
void soundVoiceSet(int voice);
int soundVoiceGet(void);
const char *soundVoiceName(int voice);

// ---- Drive state (v5.4) ----
// IDLE: stopped, bike ON. ACCEL: throttle opening (amps/RPM rising).
// CRUISE: steady. DECEL: throttle closing (amps collapsing / RPM falling).
// The synth shapes the sound per state: ACCEL louder + brighter, DECEL
// quieter + softer. Classification runs inside soundSynthSetState from
// smoothed RPM/amps deltas.
typedef enum {
  DRIVE_IDLE,
  DRIVE_ACCEL,
  DRIVE_CRUISE,
  DRIVE_DECEL
} DriveState;
DriveState soundSynthDriveState(void);
const char *soundSynthDriveStateName(void);

// ---- Shared synth core (used by both I2S and A2DP) ----
// Update pitch/volume state from live CAN data. Call ~every 20 ms from
// soundTask; both render paths read this state. Pitch range follows the
// active voice.
void soundSynthSetState(int rpm, float amps);
// v5.3: tell the synth whether CAN frames are flowing (bike ON). Parked
// (RPM 0, ~0 A) with CAN alive = idle hum; no CAN (bike OFF) = silence.
// Call from soundTask each loop with (canMessagesPerSec > 0).
void soundSynthSetCanActive(bool active);
// Fill `buf` with `frames` mono PCM samples at `sampleRate` Hz, using the
// active voice's wavetable + harmonic mix + current pitch/volume state —
// or, for voice 5 "Real Engine", the recorded engine loop resampled to
// the current playback rate. Thread-safe (mutex-guarded: the A2DP data
// callback runs in the BT task, I2S rendering in soundTask).
void soundSynthRender(int16_t *buf, int frames, int sampleRate);

// ---- Wired I2S output (MAX98357A) ----
// Install the I2S driver (idempotent; safe to call when already installed).
void soundBoosterBegin();
// Uninstall the I2S driver (idempotent).
void soundBoosterEnd();
// Render one ~16 ms chunk (256 samples @ 16 kHz) and queue it to I2S.
// No-op when the driver is not installed or sound is disabled.
void soundBoosterUpdate(int rpm, float amps);

// ---- ON/OFF state (shared by both outputs) ----
// Enable/disable. Also raises the save-pending flag (loop() writes NVS).
void soundBoosterSetEnabled(bool enabled);
bool soundBoosterIsEnabled();
// True when the enabled state changed and an NVS save is due.
bool soundBoosterSavePending();
// Clear the save-pending flag (call after writing NVS).
void soundBoosterSaveDone();

#endif  // SOUND_BOOSTER_H
