// bt_audio.h — FoxR_Joni SOUND-ONLY: soundbooster over Bluetooth A2DP
// ESP32 is the A2DP source (pschatzmann ESP32-A2DP 1.8.x, BluetoothA2DPSource).
// The user's speaker is unbranded, so pairing works by discovery, never by
// a known name. Audio is the shared synth core (sound_booster.h) rendered
// at 44.1 kHz stereo.
//
// Pairing is SAVED-MAC ONLY: A2DP connects only to the MAC saved in NVS
// (BT:SCAN then BT:PAIR <MAC>). It never auto-connects to an unpaired
// device — v3's MATCH_FIRST once grabbed a neighbor's speaker.
// Output selection: BT speaker connected -> A2DP; otherwise I2S fallback
// (MAX98357A). SOUND:ON/OFF only toggles ON/OFF — the BT state machine
// follows automatically.
#ifndef BT_AUDIO_H
#define BT_AUDIO_H

#include <Arduino.h>

// Load the saved paired MAC from NVS. Call once in setup().
void btAudioInit();
// Run the BT state machine. Call every soundTask iteration.
// soundOn: sound enabled (SOUND:ON). wifiMode: unused in the sound-only
// build (no transport modes) — always pass true.
void btAudioLoop(bool soundOn, bool wifiMode);
// True when A2DP is connected to a speaker (sound goes to BT, not I2S).
bool btAudioIsConnected();
// True when the A2DP stack is started (discovering/connecting/connected).
bool btAudioIsStarted();
// Request a timed discovery scan: prints nearby BT Classic devices
// (name + MAC + RSSI) for ~12 s, connects to none. Only runs when A2DP
// is idle (SOUND:OFF first if sound is on).
void btAudioRequestScan();
// Pair a specific MAC ("AA:BB:CC:DD:EE:FF" or "AABBCCDDEEFF"), save it to
// NVS, and (re)connect to it. Returns false on a bad MAC format.
bool btAudioPair(const char *macStr);
// Forget the saved MAC (our NVS + the library's last-connection).
void btAudioForget();
// Saved paired MAC as "AA:BB:CC:DD:EE:FF", or "" when none.
void btAudioSavedMac(char *out, size_t len);
// Print a one-line BT status summary to Serial (for BT:STATUS).
void btAudioPrintStatus();

#endif  // BT_AUDIO_H
