// sound_booster.cpp — FoxR_Joni SOUND-ONLY soundbooster
// ESP32 Arduino core 2.0.x (ESP-IDF 4.4): legacy driver/i2s.h API.
//
// Efficiency notes:
//  - 16 kHz mono 16-bit I2S, DMA 2x256 samples; I2S hardware moves the audio,
//    CPU only renders one 256-sample chunk per call (~16 ms of audio).
//  - Wavetable synthesis: 256-entry const tables in flash (sine + saw mix),
//    phase accumulator, NO per-sample sin()/float trig.
//  - Fundamental + 1 harmonic (second table read at 2x phase, per-voice level).
//  - ONE synth core shared by I2S and A2DP (see soundSynthRender): the
//    A2DP data callback renders the same state at 44.1 kHz stereo.
//  - Driver is only installed when sound is enabled; the task sleeps 100 ms
//    when idle/off, so the idle CPU cost is near zero.
//  - 5 switchable voices (Halus/Galak/Nge-bass/Sport + "Real Engine"),
//    each its own table + pitch range + harmonic mix. Voice 1 "Halus" is
//    bit-identical to the v3 sound (same table, same range, same harmonic
//    level). Voice 5 (v5.5) is a recorded engine loop resampled to follow
//    RPM (0.35x idle .. 2.0x full) with linear interpolation.
#include "sound_booster.h"
#include "engine_loop.h"
#include "driver/i2s.h"
#include <atomic>

#define SB_I2S_PORT   I2S_NUM_0
#define SB_BCLK_PIN   26
#define SB_LRCLK_PIN  25
#define SB_DIN_PIN    33
#define SB_SAMPLE_RATE 16000
#define SB_CHUNK_SAMPLES 256

// Voice 1 "Halus": sine 0.65 + saw 0.35 (smooth — the original v3 sound)
static const int16_t kWaveHalus[256] = {
   -5600,  -5301,  -5002,  -4704,  -4406,  -4108,  -3812,  -3516,
   -3221,  -2928,  -2636,  -2345,  -2056,  -1769,  -1484,  -1201,
    -920,   -642,   -366,    -93,    178,    445,    709,    970,
    1228,   1482,   1733,   1980,   2223,   2462,   2697,   2927,
    3154,   3376,   3593,   3806,   4014,   4218,   4416,   4609,
    4797,   4980,   5158,   5330,   5497,   5658,   5814,   5964,
    6108,   6247,   6380,   6506,   6627,   6742,   6851,   6954,
    7050,   7141,   7225,   7303,   7375,   7441,   7500,   7553,
    7600,   7641,   7675,   7703,   7725,   7741,   7750,   7753,
    7750,   7741,   7726,   7705,   7677,   7644,   7605,   7559,
    7508,   7452,   7389,   7321,   7247,   7168,   7083,   6993,
    6897,   6797,   6691,   6580,   6464,   6344,   6218,   6088,
    5954,   5815,   5672,   5524,   5373,   5217,   5058,   4895,
    4728,   4558,   4384,   4207,   4028,   3845,   3659,   3471,
    3280,   3087,   2891,   2694,   2494,   2293,   2089,   1885,
    1679,   1472,   1263,   1054,    844,    634,    423,    211,
       0,   -211,   -423,   -634,   -844,  -1054,  -1263,  -1472,
   -1679,  -1885,  -2089,  -2293,  -2494,  -2694,  -2891,  -3087,
   -3280,  -3471,  -3659,  -3845,  -4028,  -4207,  -4384,  -4558,
   -4728,  -4895,  -5058,  -5217,  -5373,  -5524,  -5672,  -5815,
   -5954,  -6088,  -6218,  -6344,  -6464,  -6580,  -6691,  -6797,
   -6897,  -6993,  -7083,  -7168,  -7247,  -7321,  -7389,  -7452,
   -7508,  -7559,  -7605,  -7644,  -7677,  -7705,  -7726,  -7741,
   -7750,  -7753,  -7750,  -7741,  -7725,  -7703,  -7675,  -7641,
   -7600,  -7553,  -7500,  -7441,  -7375,  -7303,  -7225,  -7141,
   -7050,  -6954,  -6851,  -6742,  -6627,  -6506,  -6380,  -6247,
   -6108,  -5964,  -5814,  -5658,  -5497,  -5330,  -5158,  -4980,
   -4797,  -4609,  -4416,  -4218,  -4014,  -3806,  -3593,  -3376,
   -3154,  -2927,  -2697,  -2462,  -2223,  -1980,  -1733,  -1482,
   -1228,   -970,   -709,   -445,   -178,     93,    366,    642,
     920,   1201,   1484,   1769,   2056,   2345,   2636,   2928,
    3221,   3516,   3812,   4108,   4406,   4704,   5002,   5301
};

// Voice 2 "Galak": sine 0.25 + saw 0.75 (aggressive, buzzy)
static const int16_t kWaveGalak[256] = {
  -12000, -11808, -11616, -11424, -11233, -11042, -10851, -10660,
  -10470, -10280, -10091,  -9902,  -9714,  -9527,  -9340,  -9154,
   -8969,  -8785,  -8602,  -8420,  -8239,  -8060,  -7881,  -7704,
   -7528,  -7353,  -7180,  -7008,  -6837,  -6669,  -6501,  -6336,
   -6172,  -6009,  -5849,  -5690,  -5533,  -5378,  -5225,  -5073,
   -4924,  -4777,  -4632,  -4488,  -4347,  -4208,  -4072,  -3937,
   -3804,  -3674,  -3546,  -3421,  -3297,  -3176,  -3057,  -2941,
   -2827,  -2715,  -2606,  -2499,  -2394,  -2292,  -2192,  -2095,
   -2000,  -1907,  -1817,  -1730,  -1644,  -1561,  -1481,  -1403,
   -1327,  -1253,  -1182,  -1114,  -1047,   -983,   -921,   -862,
    -804,   -749,   -697,   -646,   -597,   -551,   -507,   -464,
    -424,   -386,   -350,   -315,   -283,   -252,   -224,   -197,
    -172,   -148,   -126,   -106,    -87,    -70,    -55,    -41,
     -28,    -16,     -6,      3,     11,     17,     23,     27,
      31,     33,     35,     36,     36,     36,     34,     33,
      30,     28,     24,     21,     17,     13,      9,      4,
       0,     -4,     -9,    -13,    -17,    -21,    -24,    -28,
     -30,    -33,    -34,    -36,    -36,    -36,    -35,    -33,
     -31,    -27,    -23,    -17,    -11,     -3,      6,     16,
      28,     41,     55,     70,     87,    106,    126,    148,
     172,    197,    224,    252,    283,    315,    350,    386,
     424,    464,    507,    551,    597,    646,    697,    749,
     804,    862,    921,    983,   1047,   1114,   1182,   1253,
    1327,   1403,   1481,   1561,   1644,   1730,   1817,   1907,
    2000,   2095,   2192,   2292,   2394,   2499,   2606,   2715,
    2827,   2941,   3057,   3176,   3297,   3421,   3546,   3674,
    3804,   3937,   4072,   4208,   4347,   4488,   4632,   4777,
    4924,   5073,   5225,   5378,   5533,   5690,   5849,   6009,
    6172,   6336,   6501,   6669,   6837,   7008,   7180,   7353,
    7528,   7704,   7881,   8060,   8239,   8420,   8602,   8785,
    8969,   9154,   9340,   9527,   9714,   9902,  10091,  10280,
   10470,  10660,  10851,  11042,  11233,  11424,  11616,  11808
};

// Voice 3 "Nge-bass": sine 0.85 + saw 0.15 (deep, low rumble)
static const int16_t kWaveBass[256] = {
   -2400,  -2047,  -1695,  -1343,   -992,   -641,   -292,     56,
     403,    749,   1092,   1434,   1773,   2110,   2444,   2776,
    3104,   3430,   3752,   4071,   4386,   4697,   5004,   5307,
    5606,   5900,   6189,   6473,   6753,   7027,   7296,   7559,
    7817,   8069,   8314,   8554,   8788,   9015,   9236,   9450,
    9658,   9859,  10053,  10239,  10419,  10592,  10757,  10915,
   11065,  11207,  11342,  11470,  11589,  11701,  11805,  11901,
   11989,  12069,  12140,  12204,  12260,  12307,  12346,  12377,
   12400,  12415,  12421,  12419,  12410,  12391,  12365,  12331,
   12289,  12238,  12180,  12114,  12039,  11957,  11867,  11770,
   11665,  11552,  11432,  11304,  11169,  11027,  10878,  10721,
   10558,  10388,  10211,  10028,   9838,   9642,   9439,   9231,
    9017,   8797,   8571,   8339,   8103,   7861,   7614,   7362,
    7106,   6845,   6579,   6310,   6036,   5758,   5477,   5193,
    4904,   4613,   4319,   4022,   3723,   3421,   3117,   2811,
    2503,   2194,   1883,   1571,   1258,    944,    630,    315,
       0,   -315,   -630,   -944,  -1258,  -1571,  -1883,  -2194,
   -2503,  -2811,  -3117,  -3421,  -3723,  -4022,  -4319,  -4613,
   -4904,  -5193,  -5477,  -5758,  -6036,  -6310,  -6579,  -6845,
   -7106,  -7362,  -7614,  -7861,  -8103,  -8339,  -8571,  -8797,
   -9017,  -9231,  -9439,  -9642,  -9838, -10028, -10211, -10388,
  -10558, -10721, -10878, -11027, -11169, -11304, -11432, -11552,
  -11665, -11770, -11867, -11957, -12039, -12114, -12180, -12238,
  -12289, -12331, -12365, -12391, -12410, -12419, -12421, -12415,
  -12400, -12377, -12346, -12307, -12260, -12204, -12140, -12069,
  -11989, -11901, -11805, -11701, -11589, -11470, -11342, -11207,
  -11065, -10915, -10757, -10592, -10419, -10239, -10053,  -9859,
   -9658,  -9450,  -9236,  -9015,  -8788,  -8554,  -8314,  -8069,
   -7817,  -7559,  -7296,  -7027,  -6753,  -6473,  -6189,  -5900,
   -5606,  -5307,  -5004,  -4697,  -4386,  -4071,  -3752,  -3430,
   -3104,  -2776,  -2444,  -2110,  -1773,  -1434,  -1092,   -749,
    -403,    -56,    292,    641,    992,   1343,   1695,   2047
};

// Voice 4 "Sport": sine 0.5 + saw 0.5 (bright, high-revving)
static const int16_t kWaveSport[256] = {
   -8000,  -7741,  -7482,  -7224,  -6966,  -6708,  -6451,  -6195,
   -5939,  -5685,  -5431,  -5179,  -4928,  -4678,  -4430,  -4183,
   -3939,  -3696,  -3455,  -3216,  -2979,  -2744,  -2512,  -2283,
   -2055,  -1831,  -1609,  -1391,  -1175,   -962,   -753,   -546,
    -343,   -144,     53,    245,    434,    619,    801,    978,
    1152,   1321,   1487,   1648,   1805,   1958,   2107,   2251,
    2391,   2526,   2657,   2784,   2906,   3023,   3135,   3243,
    3346,   3445,   3538,   3627,   3711,   3791,   3865,   3935,
    4000,   4060,   4115,   4166,   4211,   4252,   4288,   4320,
    4346,   4368,   4385,   4398,   4406,   4409,   4407,   4401,
    4391,   4376,   4357,   4333,   4305,   4273,   4237,   4196,
    4152,   4103,   4051,   3994,   3934,   3870,   3803,   3731,
    3657,   3579,   3497,   3413,   3325,   3234,   3141,   3044,
    2945,   2842,   2738,   2631,   2521,   2409,   2295,   2179,
    2061,   1942,   1820,   1697,   1572,   1446,   1319,   1190,
    1061,    930,    799,    667,    534,    401,    268,    134,
       0,   -134,   -268,   -401,   -534,   -667,   -799,   -930,
   -1061,  -1190,  -1319,  -1446,  -1572,  -1697,  -1820,  -1942,
   -2061,  -2179,  -2295,  -2409,  -2521,  -2631,  -2738,  -2842,
   -2945,  -3044,  -3141,  -3234,  -3325,  -3413,  -3497,  -3579,
   -3657,  -3731,  -3803,  -3870,  -3934,  -3994,  -4051,  -4103,
   -4152,  -4196,  -4237,  -4273,  -4305,  -4333,  -4357,  -4376,
   -4391,  -4401,  -4407,  -4409,  -4406,  -4398,  -4385,  -4368,
   -4346,  -4320,  -4288,  -4252,  -4211,  -4166,  -4115,  -4060,
   -4000,  -3935,  -3865,  -3791,  -3711,  -3627,  -3538,  -3445,
   -3346,  -3243,  -3135,  -3023,  -2906,  -2784,  -2657,  -2526,
   -2391,  -2251,  -2107,  -1958,  -1805,  -1648,  -1487,  -1321,
   -1152,   -978,   -801,   -619,   -434,   -245,    -53,    144,
     343,    546,    753,    962,   1175,   1391,   1609,   1831,
    2055,   2283,   2512,   2744,   2979,   3216,   3455,   3696,
    3939,   4183,   4430,   4678,   4928,   5179,   5431,   5685,
    5939,   6195,   6451,   6708,   6966,   7224,   7482,   7741
};

// ---- Voice presets (SOUND-ONLY v1.0) ----
// Each voice is a wavetable + pitch range + harmonic mix. Tables live in
// flash (256 x int16 = 512 bytes each, 2 KB total). Voice 1 "Halus" is
// the original v3 sound, bit-identical (same table, same 45-240 Hz range,
// same 0.5 harmonic level).
typedef struct {
  const int16_t *table;  // 256-entry wavetable in flash (nullptr if sample)
  uint16_t freqMin;      // Hz at RPM 0 (unused if sample)
  uint16_t freqMax;      // Hz at RPM 1000 (unused if sample)
  uint8_t harmQ8;        // 2nd-harmonic level * 256 (128 = 0.5, unused if sample)
  const char *name;
  bool isSample;         // true: play the recorded engine loop (voice 5)
} SoundVoiceConfig;

static const SoundVoiceConfig kVoices[SOUND_VOICE_COUNT] = {
  { kWaveHalus,  45, 240, 128, "Halus",       false },  // 1: smooth (v3 original)
  { kWaveGalak,  45, 260, 154, "Galak",       false },  // 2: aggressive, buzzy
  { kWaveBass,   35, 180,  77, "Nge-bass",    false },  // 3: deep, low rumble
  { kWaveSport,  60, 320, 179, "Sport",       false },  // 4: bright, high-revving
  { nullptr,      0,   0,   0, "Real Engine", true  },  // 5: recorded loop (v5.5)
};

// Active voice, 0-based. Single byte: written from loop() (menu/Serial),
// read from soundTask + the A2DP callback — aligned single-byte access is
// atomic on ESP32; render snapshots the index at the start of each call.
static uint8_t s_voice = 0;

static std::atomic<bool> s_enabled{false};
static std::atomic<bool> s_savePending{false};
static bool s_driverInstalled = false;  // only touched from Core 1 contexts
static int16_t s_chunk[SB_CHUNK_SAMPLES];

// ---- Shared synth state ----
// Written by soundSynthSetState() (soundTask only), read by both render
// paths. Single-word aligned reads/writes are atomic on ESP32.
static uint32_t s_freq = 45;   // Hz
static int s_vol = 0;          // 0..255
static uint32_t s_phase = 0;   // 32-bit phase accumulator (mutex-guarded)
// v5.3: true while CAN frames are arriving (bike ON). Written by
// soundSynthSetCanActive() (soundTask only), read by soundSynthSetState().
static bool s_canActive = false;
// v5.4 drive state + shaping multipliers (Q8, 256 = 1.0x). Written by
// soundSynthSetState() (soundTask only); s_harmMulQ8 is read by the
// render paths (same single-word pattern as s_vol).
static DriveState s_drive = DRIVE_CRUISE;
static int s_volMulQ8 = 256;
static int s_harmMulQ8 = 256;
// v5.5 sample playback (voice 5 "Real Engine"): s_rateQ16 is the loop
// playback rate in Q16 (65536 = 1.0x), written by soundSynthSetState()
// (soundTask only), read by the render paths. s_loopPosQ16 is the loop
// position in Q16.16 samples (integer part = sample index); only touched
// inside soundSynthRender under the synth mutex.
static uint32_t s_rateQ16 = 22938;  // 0.35x (idle)
static uint32_t s_loopPosQ16 = 0;

// Spinlock guarding the phase accumulator + render loop, so the I2S path
// (soundTask) and the A2DP data callback (BT task) never interleave. The
// render loop is only ~256 table lookups (tens of microseconds), so holding
// the lock across it is fine.
static portMUX_TYPE s_synthMux = portMUX_INITIALIZER_UNLOCKED;

// ---- Voice selection ----
void soundVoiceSet(int voice) {
  if (voice < 1) voice = 1;
  if (voice > SOUND_VOICE_COUNT) voice = SOUND_VOICE_COUNT;
  s_voice = (uint8_t)(voice - 1);
}

int soundVoiceGet(void) {
  return (int)s_voice + 1;
}

const char *soundVoiceName(int voice) {
  if (voice < 1) voice = 1;
  if (voice > SOUND_VOICE_COUNT) voice = SOUND_VOICE_COUNT;
  return kVoices[voice - 1].name;
}

void soundSynthSetState(int rpm, float amps) {
  // Pitch: RPM 0..1000 -> voice's freqMin..freqMax Hz.
  if (rpm < 0) rpm = 0;
  if (rpm > 1000) rpm = 1000;
  const SoundVoiceConfig *cfg = &kVoices[s_voice];
  s_freq = cfg->freqMin +
           (uint32_t)((rpm * (uint32_t)(cfg->freqMax - cfg->freqMin)) / 1000);

  // v5.5 sample playback rate (voice 5 "Real Engine"): 0.35x at idle ..
  // 2.0x at full RPM (Q16: 22938 .. 131072). v5.6: idle lowered from
  // 0.6x after the user picked the 0.35x preview (sample 2) over the
  // GameSFX idle loop — deeper and slower at idle, same scream at full.
  // Eased toward the target (~80 ms to 63%) so a sudden RPM jump
  // doesn't step the pitch audibly. Computed for every voice; only the
  // sample render reads it.
  // Signed math: an unsigned (target - current) would wrap on slowdown.
  int32_t rateTarget = 22938 + (rpm * 108134) / 1000;
  s_rateQ16 =
      (uint32_t)((int32_t)s_rateQ16 + (rateTarget - (int32_t)s_rateQ16) / 4);

  // Volume: the LOUDER of an amps term and an RPM floor.
  // v5.2 fix: the original code used amps only (silent at ~0 A), but on a
  // stand / light load / regen the wheel spins at high RPM while amps sit
  // at ~0 or negative (observed: RPM 339, -0.9 A) — and the sound was
  // silent even though the motor was spinning. A real engine is audible
  // whenever it turns, so RPM alone must produce sound.
  // Amps term: silent at <=0.5 A (incl. negative/regen), full at ~30 A.
  int vol = 0;
  if (amps > 0.5f) {
    vol = (int)(amps * 255.0f / 30.0f);
    if (vol > 255) vol = 255;
  }
  // RPM floor: spinning wheel = audible hum even at 0 A.
  // 40 (~16%) just above 0 RPM, rising to 140 (~55%) at 1000 RPM.
  if (rpm > 0) {
    int rpmVol = 40 + (rpm * 100) / 1000;
    if (rpmVol > vol) vol = rpmVol;
  }
  // Parked with no current: idle hum if the bike is ON (CAN flowing),
  // silence if it is OFF (no CAN). v5.3: the original code was silent
  // whenever RPM was 0, so a stopped bike made no sound at all — the
  // user wants a gas-engine idle. 40/255 matches the just-spinning RPM
  // floor, so idle blends smoothly into rolling.
  if (rpm == 0 && amps <= 0.5f) vol = s_canActive ? 40 : 0;

  // v5.4 drive states: classify from smoothed RPM/amps deltas and shape
  // the sound per state. Runs at most every 10 ms: soundBoosterUpdate
  // (I2S path) calls this a second time with the same values right after
  // soundTask, and that duplicate must not dilute the deltas.
  static int prevRpm = 0;
  static float prevAmps = 0.0f;
  static float emaDrpm = 0.0f;   // RPM change per tick, smoothed
  static float emaDamps = 0.0f;  // amps change per tick, smoothed
  static unsigned long lastStateMs = 0;
  unsigned long nowMs = millis();
  if (nowMs - lastStateMs >= 10) {
    lastStateMs = nowMs;
    emaDrpm += 0.3f * ((float)(rpm - prevRpm) - emaDrpm);
    emaDamps += 0.3f * ((amps - prevAmps) - emaDamps);
    prevRpm = rpm;
    prevAmps = amps;

    DriveState drive;
    if (rpm <= 10 && amps <= 0.5f) {
      drive = s_canActive ? DRIVE_IDLE : DRIVE_CRUISE;
    } else if (emaDamps > 0.08f || emaDrpm > 3.0f) {
      drive = DRIVE_ACCEL;  // throttle opening: amps spike first
    } else if (emaDamps < -0.08f || emaDrpm < -3.0f) {
      drive = DRIVE_DECEL;  // throttle closing: amps collapse, RPM decays
    } else {
      drive = DRIVE_CRUISE;
    }
    s_drive = drive;

    // Targets: ACCEL louder + brighter, DECEL quieter + softer.
    int volMulTarget = 256, harmMulTarget = 256;
    if (drive == DRIVE_ACCEL) {
      volMulTarget = 333;   // x1.30
      harmMulTarget = 320;  // x1.25
    } else if (drive == DRIVE_DECEL) {
      volMulTarget = 179;   // x0.70
      harmMulTarget = 192;  // x0.75
    }
    // Ease multipliers toward their targets (~130 ms to 63%) so a
    // one-tick misclassification never steps the sound audibly.
    s_volMulQ8 += (volMulTarget - s_volMulQ8) / 6;
    s_harmMulQ8 += (harmMulTarget - s_harmMulQ8) / 6;
  }

  // Apply the drive-state volume shaping (clamped to 0..255).
  s_vol = (vol * s_volMulQ8) >> 8;
  if (s_vol > 255) s_vol = 255;
}

DriveState soundSynthDriveState(void) { return s_drive; }

const char *soundSynthDriveStateName(void) {
  switch (s_drive) {
    case DRIVE_IDLE: return "IDLE";
    case DRIVE_ACCEL: return "ACCEL";
    case DRIVE_DECEL: return "DECEL";
    default: return "CRUISE";
  }
}

void soundSynthSetCanActive(bool active) {
  s_canActive = active;
}

void soundSynthRender(int16_t *buf, int frames, int sampleRate) {
  if (buf == nullptr || frames <= 0 || sampleRate <= 0) return;
  portENTER_CRITICAL(&s_synthMux);
  // Snapshot the active voice at the start of the call so a voice change
  // from loop() mid-render cannot mix two voices in one buffer.
  const SoundVoiceConfig *cfg = &kVoices[s_voice];
  const int16_t *table = cfg->table;
  // v5.4: drive-state harmonic shaping (ACCEL brighter, DECEL softer).
  int harmQ8 = (cfg->harmQ8 * s_harmMulQ8) >> 8;
  uint32_t freq = s_freq;
  int vol = s_vol;
  if (cfg->isSample) {
    // v5.5: resample the recorded engine loop at the current playback
    // rate with linear interpolation. The loop is 16 kHz; step is in
    // Q16.16 loop samples per output sample. The loop joint is
    // crossfaded in the source data, so wrapping is click-free.
    uint32_t step = (uint32_t)(((uint64_t)s_rateQ16 * 16000) /
                               (uint32_t)sampleRate);
    for (int i = 0; i < frames; i++) {
      uint32_t idx = s_loopPosQ16 >> 16;
      uint32_t idxNext = idx + 1;
      if (idxNext >= kEngineLoopLen) idxNext = 0;
      int32_t a = kEngineLoop[idx];
      int32_t b = kEngineLoop[idxNext];
      int32_t s = a + (int32_t)(((int64_t)(b - a) *
                                (int64_t)(s_loopPosQ16 & 0xFFFF)) >> 16);
      s_loopPosQ16 += step;
      // Step is at most 2 samples, so one subtract restores the range.
      if ((s_loopPosQ16 >> 16) >= kEngineLoopLen) {
        s_loopPosQ16 -= ((uint32_t)kEngineLoopLen << 16);
      }
      buf[i] = (int16_t)((s * vol) >> 8);
    }
    portEXIT_CRITICAL(&s_synthMux);
    return;
  }
  // Phase step for this frequency: (freq << 32) / sampleRate.
  uint32_t step = (uint32_t)(((uint64_t)freq << 32) / (uint32_t)sampleRate);
  for (int i = 0; i < frames; i++) {
    // int32 accumulator: the loudest voice (Galak) peaks near 20k, and
    // the harmonic add must not overflow before the volume scaling.
    // Harmonic uses truncating division (like the original / 2), so voice
    // 1 (harmQ8 = 128) renders bit-identical to v3.
    int32_t s = table[(s_phase >> 24) & 0xFF];
    s += (table[(s_phase >> 23) & 0xFF] * harmQ8) / 256;  // 2nd harmonic
    s_phase += step;
    buf[i] = (int16_t)((s * vol) >> 8);
  }
  portEXIT_CRITICAL(&s_synthMux);
}

void soundBoosterBegin() {
  if (s_driverInstalled) return;
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
  cfg.sample_rate = SB_SAMPLE_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  cfg.dma_buf_count = 2;
  cfg.dma_buf_len = SB_CHUNK_SAMPLES;
  cfg.use_apll = false;
  cfg.tx_desc_auto_clear = true;
  if (i2s_driver_install(SB_I2S_PORT, &cfg, 0, NULL) != ESP_OK) {
    Serial.println("[Sound] ERROR: i2s_driver_install failed");
    return;
  }
  i2s_pin_config_t pins = {};
  pins.bck_io_num = SB_BCLK_PIN;
  pins.ws_io_num = SB_LRCLK_PIN;
  pins.data_out_num = SB_DIN_PIN;
  pins.data_in_num = I2S_PIN_NO_CHANGE;
  if (i2s_set_pin(SB_I2S_PORT, &pins) != ESP_OK) {
    Serial.println("[Sound] ERROR: i2s_set_pin failed");
    i2s_driver_uninstall(SB_I2S_PORT);
    return;
  }
  i2s_zero_dma_buffer(SB_I2S_PORT);
  s_driverInstalled = true;
  Serial.println("[Sound] I2S started (16 kHz mono, BCLK 26 / LRCLK 25 / DIN 33)");
}

void soundBoosterEnd() {
  if (!s_driverInstalled) return;
  i2s_driver_uninstall(SB_I2S_PORT);
  s_driverInstalled = false;
  Serial.println("[Sound] I2S stopped");
}

void soundBoosterSetEnabled(bool enabled) {
  bool prev = s_enabled.exchange(enabled, std::memory_order_acq_rel);
  if (prev != enabled) {
    s_savePending.store(true, std::memory_order_release);
  }
}

bool soundBoosterIsEnabled() {
  return s_enabled.load(std::memory_order_acquire);
}

bool soundBoosterSavePending() {
  return s_savePending.load(std::memory_order_acquire);
}

void soundBoosterSaveDone() {
  s_savePending.store(false, std::memory_order_release);
}

void soundBoosterUpdate(int rpm, float amps) {
  if (!s_driverInstalled || !s_enabled.load(std::memory_order_acquire)) return;
  soundSynthSetState(rpm, amps);
  soundSynthRender(s_chunk, SB_CHUNK_SAMPLES, SB_SAMPLE_RATE);
  size_t written = 0;
  i2s_write(SB_I2S_PORT, s_chunk, sizeof(s_chunk), &written, pdMS_TO_TICKS(20));
}
